<div class="list-group">
  <a href="/management/category" class="list-group-item list-group-item-action"><i class="fas fa-menorah"></i>

 Category</a>
  <a href="/management/menu" class="list-group-item list-group-item-action"><i class="fas fa-bars"></i>

 Menu</a>
  <a href="#" class="list-group-item list-group-item-action"><i class="fas fa-chair"></i>

 Table</a>
  <a href="#" class="list-group-item list-group-item-action"><i class="far fa-user"></i>

 User</a>
</div>
